"""Adds Zuzu automation services to the generated AndroidManifest.xml (safe to run twice)."""
import os
import xml.etree.ElementTree as ET

p = "android/app/src/main/AndroidManifest.xml"
assert os.path.exists(p), "Missing " + p
s = open(p, encoding="utf-8").read()

block = "\n".join([
    '        <service',
    '            android:name=".ZuzuAccessibilityService"',
    '            android:exported="true"',
    '            android:label="Zuzu AI Accessibility"',
    '            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">',
    '            <intent-filter>',
    '                <action android:name="android.accessibilityservice.AccessibilityService" />',
    '            </intent-filter>',
    '            <meta-data',
    '                android:name="android.accessibilityservice"',
    '                android:resource="@xml/zuzu_accessibility_config" />',
    '        </service>',
    '        <service',
    '            android:name=".ZuzuNotificationListener"',
    '            android:exported="true"',
    '            android:label="Zuzu AI Notification Access"',
    '            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">',
    '            <intent-filter>',
    '                <action android:name="android.service.notification.NotificationListenerService" />',
    '            </intent-filter>',
    '        </service>',
    '    </application>',
])

if "ZuzuAccessibilityService" not in s:
    s = s.replace("</application>", block, 1)

open(p, "w", encoding="utf-8").write(s)
ET.parse(p)
print("Automation services added to AndroidManifest.xml and XML validated")
