import { Capacitor, registerPlugin } from '@capacitor/core';

export interface AutomationStatus {
  accessibilityEnabled: boolean;
  accessibilityConnected: boolean;
  notificationListenerEnabled: boolean;
}

export interface AutoReplyConfig {
  enabled: boolean;
  message: string;
  cooldownMinutes: number;
  apps: string;
}

export interface NotificationItem {
  package: string;
  title: string;
  text: string;
  time: number;
  autoReplied: boolean;
}

export interface ActionResult {
  success: boolean;
  reason?: string;
  texts?: string[];
}

const ZuzuAutomation: any =
  typeof window !== 'undefined' ? registerPlugin<any>('ZuzuAutomation') : null;

export function isAutomationAvailable(): boolean {
  try {
    return Capacitor.isNativePlatform() && !!ZuzuAutomation;
  } catch {
    return false;
  }
}

const OFF_STATUS: AutomationStatus = {
  accessibilityEnabled: false,
  accessibilityConnected: false,
  notificationListenerEnabled: false,
};

export async function getAutomationStatus(): Promise<AutomationStatus> {
  if (!isAutomationAvailable()) return OFF_STATUS;
  try {
    return (await ZuzuAutomation.getAutomationStatus()) as AutomationStatus;
  } catch {
    return OFF_STATUS;
  }
}

export async function openAccessibilitySettings(): Promise<void> {
  if (isAutomationAvailable()) await ZuzuAutomation.openAccessibilitySettings();
}

export async function openNotificationListenerSettings(): Promise<void> {
  if (isAutomationAvailable()) await ZuzuAutomation.openNotificationListenerSettings();
}

async function run(method: string, args?: Record<string, unknown>): Promise<ActionResult> {
  if (!isAutomationAvailable()) return { success: false, reason: 'not_native' };
  try {
    return (await ZuzuAutomation[method](args || {})) as ActionResult;
  } catch (e: any) {
    return { success: false, reason: String(e?.message || e) };
  }
}

/** action: back | home | recents | notifications | quick_settings | lock_screen | screenshot | power_dialog */
export const performGlobalAction = (action: string) => run('performGlobalAction', { action });
export const clickByText = (text: string) => run('clickByText', { text });
export const typeText = (text: string) => run('typeText', { text });
export const scrollScreen = (direction: 'up' | 'down') => run('scrollScreen', { direction });
export const tapAt = (x: number, y: number) => run('tapAt', { x, y });
export const readScreen = () => run('readScreen');

export async function getAutoReplyConfig(): Promise<AutoReplyConfig | null> {
  if (!isAutomationAvailable()) return null;
  try {
    return (await ZuzuAutomation.getAutoReplyConfig()) as AutoReplyConfig;
  } catch {
    return null;
  }
}

export async function setAutoReply(cfg: Partial<AutoReplyConfig>): Promise<AutoReplyConfig | null> {
  if (!isAutomationAvailable()) return null;
  try {
    return (await ZuzuAutomation.setAutoReply(cfg)) as AutoReplyConfig;
  } catch {
    return null;
  }
}

export async function getRecentNotifications(): Promise<NotificationItem[]> {
  if (!isAutomationAvailable()) return [];
  try {
    const r = await ZuzuAutomation.getRecentNotifications();
    return (r?.items || []) as NotificationItem[];
  } catch {
    return [];
  }
}

export async function clearNotifications(): Promise<void> {
  if (isAutomationAvailable()) await ZuzuAutomation.clearNotifications();
}
