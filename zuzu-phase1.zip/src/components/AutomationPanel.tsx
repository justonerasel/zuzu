import React, { useCallback, useEffect, useState } from 'react';
import {
  AutomationStatus,
  AutoReplyConfig,
  getAutomationStatus,
  getAutoReplyConfig,
  isAutomationAvailable,
  openAccessibilitySettings,
  openNotificationListenerSettings,
  setAutoReply,
} from '../utils/automation';

const EMPTY: AutomationStatus = {
  accessibilityEnabled: false,
  accessibilityConnected: false,
  notificationListenerEnabled: false,
};

function StatusPill({ on }: { on: boolean }) {
  return (
    <span
      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
        on
          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
          : 'bg-rose-100 text-rose-800 border-rose-300'
      }`}
    >
      {on ? 'চালু আছে' : 'বন্ধ'}
    </span>
  );
}

export default function AutomationPanel() {
  const [status, setStatus] = useState<AutomationStatus>(EMPTY);
  const [cfg, setCfg] = useState<AutoReplyConfig | null>(null);
  const [message, setMessage] = useState('');
  const native = isAutomationAvailable();

  const refresh = useCallback(async () => {
    setStatus(await getAutomationStatus());
    const c = await getAutoReplyConfig();
    if (c) {
      setCfg(c);
      setMessage(c.message);
    }
  }, []);

  useEffect(() => {
    refresh();
    const onVisible = () => {
      if (document.visibilityState === 'visible') refresh();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [refresh]);

  const toggleAutoReply = async () => {
    if (!cfg) return;
    const next = await setAutoReply({ enabled: !cfg.enabled, message });
    if (next) setCfg(next);
  };

  const saveMessage = async () => {
    const next = await setAutoReply({ message });
    if (next) setCfg(next);
  };

  if (!native) {
    return (
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-[11px] text-amber-900">
        ফোন নিয়ন্ত্রণ ও অটো-রিপ্লাই শুধু ইনস্টল করা APK তে কাজ করে।
      </div>
    );
  }

  return (
    <div className="p-4 bg-white/95 border border-teal-200 rounded-2xl shadow-xs space-y-3 text-slate-800">
      <div className="text-xs font-bold uppercase tracking-wider text-teal-900">
        ফোন নিয়ন্ত্রণ ও অটো-রিপ্লাই
      </div>

      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="text-xs font-bold">অ্যাক্সেসিবিলিটি সার্ভিস</div>
          <p className="text-[10px] text-slate-500 leading-snug">
            স্ক্রিন পড়া, ট্যাপ, টাইপ, স্ক্রল, ব্যাক/হোম। Android নিয়ম অনুযায়ী আপনাকে একবার নিজে অন করতে হবে।
          </p>
        </div>
        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
          <StatusPill on={status.accessibilityConnected} />
          {!status.accessibilityConnected && (
            <button
              type="button"
              onClick={openAccessibilitySettings}
              className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-teal-600 text-white"
            >
              অন করুন
            </button>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 border-t border-slate-100 pt-3">
        <div className="min-w-0">
          <div className="text-xs font-bold">নোটিফিকেশন অ্যাক্সেস</div>
          <p className="text-[10px] text-slate-500 leading-snug">
            মেসেজের নোটিফিকেশন পড়া ও অটো-রিপ্লাই পাঠানোর জন্য।
          </p>
        </div>
        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
          <StatusPill on={status.notificationListenerEnabled} />
          {!status.notificationListenerEnabled && (
            <button
              type="button"
              onClick={openNotificationListenerSettings}
              className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-teal-600 text-white"
            >
              অন করুন
            </button>
          )}
        </div>
      </div>

      <div className="border-t border-slate-100 pt-3 space-y-2">
        <div className="flex items-center justify-between">
          <div className="text-xs font-bold">ব্যস্ত থাকলে অটো-রিপ্লাই</div>
          <button
            type="button"
            onClick={toggleAutoReply}
            disabled={!cfg || !status.notificationListenerEnabled}
            className={`text-[10px] font-bold px-3 py-1 rounded-lg disabled:opacity-40 ${
              cfg?.enabled ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
            }`}
          >
            {cfg?.enabled ? 'চালু' : 'বন্ধ'}
          </button>
        </div>
        <textarea
          value={message}
          onChange={e => setMessage(e.target.value)}
          rows={3}
          className="w-full text-[11px] p-2 rounded-xl border border-slate-200 bg-white"
          placeholder="অটো-রিপ্লাইয়ের মেসেজ লিখুন"
        />
        <button
          type="button"
          onClick={saveMessage}
          className="text-[10px] font-bold px-3 py-1.5 rounded-lg bg-teal-600 text-white"
        >
          মেসেজ সেভ করুন
        </button>
        <p className="text-[10px] text-slate-500 leading-snug">
          গ্রুপ চ্যাটে রিপ্লাই যাবে না। একই ব্যক্তিকে ৩০ মিনিটে একবারের বেশি যাবে না।
        </p>
      </div>
    </div>
  );
}
