Zuzu Phase 1 — ফোন নিয়ন্ত্রণ (Accessibility) + নোটিফিকেশন পড়া + অটো-রিপ্লাই

এই ZIP এর ভেতরের ফোল্ডার ও ফাইলগুলো আপনার GitHub রিপোর (zuzu) একই জায়গায় বসবে।
যেগুলো আগে থেকে আছে (MainActivity.java, SettingsView.tsx, build-apk.yml) সেগুলো রিপ্লেস হবে।

নতুন ফাইল:
- native-android/app/src/main/java/com/zuzu/ai/assistant/ZuzuAccessibilityService.java
- native-android/app/src/main/java/com/zuzu/ai/assistant/ZuzuNotificationListener.java
- native-android/app/src/main/java/com/zuzu/ai/assistant/ZuzuAutomationPlugin.java
- native-android/app/src/main/res/xml/zuzu_accessibility_config.xml
- native-android/app/src/main/res/values/zuzu_automation_strings.xml
- scripts/patch_automation_manifest.py
- src/utils/automation.ts
- src/components/AutomationPanel.tsx

রিপ্লেস হবে:
- native-android/app/src/main/java/com/zuzu/ai/assistant/MainActivity.java
- src/components/SettingsView.tsx
- .github/workflows/build-apk.yml
