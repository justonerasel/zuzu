package com.zuzu.ai.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Zuzu AI Accessibility Service.
 * Lets the voice assistant read the screen, tap, type, scroll and press system buttons.
 * The user must switch this service ON once in Android Settings > Accessibility.
 */
public class ZuzuAccessibilityService extends AccessibilityService {

    private static volatile ZuzuAccessibilityService instance;

    public static ZuzuAccessibilityService get() {
        return instance;
    }

    public static boolean isConnected() {
        return instance != null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Zuzu acts only on demand (voice command), so nothing to do per event.
    }

    @Override
    public void onInterrupt() {
    }

    /** back, home, recents, notifications, quick_settings, lock_screen, screenshot, power_dialog */
    public boolean doGlobalAction(String name) {
        if (name == null) return false;
        switch (name.toLowerCase(Locale.ROOT)) {
            case "back":
                return performGlobalAction(GLOBAL_ACTION_BACK);
            case "home":
                return performGlobalAction(GLOBAL_ACTION_HOME);
            case "recents":
                return performGlobalAction(GLOBAL_ACTION_RECENTS);
            case "notifications":
                return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
            case "quick_settings":
                return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
            case "power_dialog":
                return performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
            case "lock_screen":
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
                }
                return false;
            case "screenshot":
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    return performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
                }
                return false;
            default:
                return false;
        }
    }

    /** Taps the first on-screen element whose text or description contains the given text. */
    public boolean clickByText(String text) {
        if (text == null || text.trim().isEmpty()) return false;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;

        List<AccessibilityNodeInfo> matches = root.findAccessibilityNodeInfosByText(text.trim());
        if (matches == null || matches.isEmpty()) return false;

        for (AccessibilityNodeInfo match : matches) {
            AccessibilityNodeInfo node = match;
            while (node != null && !node.isClickable()) {
                node = node.getParent();
            }
            if (node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }
        }

        // Fallback: tap the centre of the first match.
        Rect bounds = new Rect();
        matches.get(0).getBoundsInScreen(bounds);
        if (bounds.width() > 0 && bounds.height() > 0) {
            return tapAt(bounds.centerX(), bounds.centerY());
        }
        return false;
    }

    /** Types text into the focused input box (or the first input box on screen). */
    public boolean typeText(String text) {
        if (text == null) return false;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;

        AccessibilityNodeInfo target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (target == null || !target.isEditable()) {
            target = findFirst(root, true, false);
        }
        if (target == null) return false;

        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    /** direction: "down" (see more below) or "up". */
    public boolean scroll(String direction) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo node = findFirst(root, false, true);
        if (node == null) return false;
        boolean down = direction == null || !"up".equalsIgnoreCase(direction);
        return node.performAction(down
                ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }

    public boolean tapAt(float x, float y) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 60));
        return dispatchGesture(builder.build(), null, null);
    }

    /** Returns the visible texts on the current screen (max 200 items). */
    public List<String> readScreen() {
        List<String> out = new ArrayList<>();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return out;
        collectTexts(root, out, 0);
        return out;
    }

    private void collectTexts(AccessibilityNodeInfo node, List<String> out, int depth) {
        if (node == null || out.size() >= 200 || depth > 40) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null && t.toString().trim().length() > 0) {
            out.add(t.toString().trim());
        } else if (d != null && d.toString().trim().length() > 0) {
            out.add(d.toString().trim());
        }
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) {
            collectTexts(node.getChild(i), out, depth + 1);
        }
    }

    private AccessibilityNodeInfo findFirst(AccessibilityNodeInfo node, boolean editable, boolean scrollable) {
        if (node == null) return null;
        if (editable && node.isEditable()) return node;
        if (scrollable && node.isScrollable()) return node;
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) {
            AccessibilityNodeInfo found = findFirst(node.getChild(i), editable, scrollable);
            if (found != null) return found;
        }
        return null;
    }
}
