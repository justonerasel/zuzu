package com.zuzu.ai.assistant;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.text.TextUtils;

import androidx.core.app.NotificationManagerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.List;

/**
 * Capacitor plugin "ZuzuAutomation": phone control (Accessibility) + notification reading / auto-reply.
 */
@CapacitorPlugin(name = "ZuzuAutomation")
public class ZuzuAutomationPlugin extends Plugin {

    private static volatile ZuzuAutomationPlugin instance;

    @Override
    public void load() {
        super.load();
        instance = this;
    }

    /** Called by the notification listener when a new notification arrives. */
    public static void emitNotification(ZuzuNotificationListener.NotifItem item) {
        ZuzuAutomationPlugin p = instance;
        if (p == null) return;
        try {
            p.notifyListeners("notificationReceived", ZuzuNotificationListener.toJs(item));
        } catch (Exception ignored) {
        }
    }

    private boolean isAccessibilityEnabledInSettings(Context ctx) {
        try {
            String expected = new ComponentName(ctx, ZuzuAccessibilityService.class).flattenToString();
            String enabled = Settings.Secure.getString(
                    ctx.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(enabled)) return false;
            for (String s : enabled.split(":")) {
                if (s.equalsIgnoreCase(expected)) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private boolean isListenerEnabled(Context ctx) {
        try {
            return NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    @PluginMethod
    public void getAutomationStatus(PluginCall call) {
        Context ctx = getContext();
        JSObject ret = new JSObject();
        ret.put("accessibilityEnabled", isAccessibilityEnabledInSettings(ctx));
        ret.put("accessibilityConnected", ZuzuAccessibilityService.isConnected());
        ret.put("notificationListenerEnabled", isListenerEnabled(ctx));
        call.resolve(ret);
    }

    @PluginMethod
    public void openAccessibilitySettings(PluginCall call) {
        openSettings(call, Settings.ACTION_ACCESSIBILITY_SETTINGS);
    }

    @PluginMethod
    public void openNotificationListenerSettings(PluginCall call) {
        openSettings(call, "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
    }

    private void openSettings(PluginCall call, String action) {
        try {
            Intent intent = new Intent(action);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            JSObject ret = new JSObject();
            ret.put("opened", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Could not open settings: " + e.getMessage());
        }
    }

    private ZuzuAccessibilityService requireService(PluginCall call) {
        ZuzuAccessibilityService s = ZuzuAccessibilityService.get();
        if (s == null) {
            JSObject r = new JSObject();
            r.put("success", false);
            r.put("reason", "accessibility_off");
            call.resolve(r);
        }
        return s;
    }

    private void resolveBool(PluginCall call, boolean ok) {
        JSObject r = new JSObject();
        r.put("success", ok);
        call.resolve(r);
    }

    @PluginMethod
    public void performGlobalAction(PluginCall call) {
        ZuzuAccessibilityService s = requireService(call);
        if (s == null) return;
        resolveBool(call, s.doGlobalAction(call.getString("action", "")));
    }

    @PluginMethod
    public void clickByText(PluginCall call) {
        ZuzuAccessibilityService s = requireService(call);
        if (s == null) return;
        resolveBool(call, s.clickByText(call.getString("text", "")));
    }

    @PluginMethod
    public void typeText(PluginCall call) {
        ZuzuAccessibilityService s = requireService(call);
        if (s == null) return;
        resolveBool(call, s.typeText(call.getString("text", "")));
    }

    @PluginMethod
    public void scrollScreen(PluginCall call) {
        ZuzuAccessibilityService s = requireService(call);
        if (s == null) return;
        resolveBool(call, s.scroll(call.getString("direction", "down")));
    }

    @PluginMethod
    public void tapAt(PluginCall call) {
        ZuzuAccessibilityService s = requireService(call);
        if (s == null) return;
        Double x = call.getDouble("x", 0.0);
        Double y = call.getDouble("y", 0.0);
        resolveBool(call, s.tapAt(x.floatValue(), y.floatValue()));
    }

    @PluginMethod
    public void readScreen(PluginCall call) {
        ZuzuAccessibilityService s = requireService(call);
        if (s == null) return;
        JSArray arr = new JSArray();
        for (String t : s.readScreen()) {
            arr.put(t);
        }
        JSObject r = new JSObject();
        r.put("success", true);
        r.put("texts", arr);
        call.resolve(r);
    }

    @PluginMethod
    public void setAutoReply(PluginCall call) {
        SharedPreferences.Editor ed = getContext()
                .getSharedPreferences(ZuzuNotificationListener.PREFS, Context.MODE_PRIVATE).edit();
        if (call.hasOption("enabled")) {
            ed.putBoolean(ZuzuNotificationListener.KEY_ENABLED, Boolean.TRUE.equals(call.getBoolean("enabled", false)));
        }
        if (call.hasOption("message")) {
            ed.putString(ZuzuNotificationListener.KEY_MESSAGE, call.getString("message", ZuzuNotificationListener.DEFAULT_MESSAGE));
        }
        if (call.hasOption("cooldownMinutes")) {
            Integer c = call.getInt("cooldownMinutes", 30);
            ed.putInt(ZuzuNotificationListener.KEY_COOLDOWN_MIN, c == null ? 30 : c);
        }
        if (call.hasOption("apps")) {
            ed.putString(ZuzuNotificationListener.KEY_APPS, call.getString("apps", ZuzuNotificationListener.DEFAULT_APPS));
        }
        ed.apply();
        getAutoReplyConfig(call);
    }

    @PluginMethod
    public void getAutoReplyConfig(PluginCall call) {
        SharedPreferences p = getContext()
                .getSharedPreferences(ZuzuNotificationListener.PREFS, Context.MODE_PRIVATE);
        JSObject r = new JSObject();
        r.put("enabled", p.getBoolean(ZuzuNotificationListener.KEY_ENABLED, false));
        r.put("message", p.getString(ZuzuNotificationListener.KEY_MESSAGE, ZuzuNotificationListener.DEFAULT_MESSAGE));
        r.put("cooldownMinutes", p.getInt(ZuzuNotificationListener.KEY_COOLDOWN_MIN, 30));
        r.put("apps", p.getString(ZuzuNotificationListener.KEY_APPS, ZuzuNotificationListener.DEFAULT_APPS));
        call.resolve(r);
    }

    @PluginMethod
    public void getRecentNotifications(PluginCall call) {
        JSArray arr = new JSArray();
        List<ZuzuNotificationListener.NotifItem> items = ZuzuNotificationListener.getRecent();
        for (ZuzuNotificationListener.NotifItem it : items) {
            arr.put(ZuzuNotificationListener.toJs(it));
        }
        JSObject r = new JSObject();
        r.put("items", arr);
        call.resolve(r);
    }

    @PluginMethod
    public void clearNotifications(PluginCall call) {
        ZuzuNotificationListener.clearRecent();
        resolveBool(call, true);
    }
}
