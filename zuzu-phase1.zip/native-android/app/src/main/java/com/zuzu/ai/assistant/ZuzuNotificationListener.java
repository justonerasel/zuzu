package com.zuzu.ai.assistant;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import com.getcapacitor.JSObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Zuzu AI Notification Listener.
 * - Remembers the latest notifications so the assistant can read them out later.
 * - Optionally sends ONE polite auto-reply to a person (per cooldown) using the
 *   normal Android "quick reply" button of WhatsApp / Messenger / IMO / Telegram etc.
 */
public class ZuzuNotificationListener extends NotificationListenerService {

    public static final String PREFS = "ZuzuAutomationPrefs";
    public static final String KEY_ENABLED = "auto_reply_enabled";
    public static final String KEY_MESSAGE = "auto_reply_message";
    public static final String KEY_COOLDOWN_MIN = "auto_reply_cooldown_min";
    public static final String KEY_APPS = "auto_reply_apps";

    public static final String DEFAULT_MESSAGE =
            "আমি এখন একটু ব্যস্ত আছি। ফ্রি হলেই আপনাকে রিপ্লাই দেব। (Zuzu AI অটো-রিপ্লাই)";
    public static final String DEFAULT_APPS =
            "com.whatsapp,com.facebook.orca,com.imo.android.imoim,org.telegram.messenger";

    private static final int MAX_RECENT = 60;

    public static class NotifItem {
        public String pkg;
        public String title;
        public String text;
        public long time;
        public boolean autoReplied;
    }

    private static final List<NotifItem> RECENT = new ArrayList<>();
    private static final Map<String, Long> LAST_REPLY_AT = new HashMap<>();
    private static volatile ZuzuNotificationListener instance;

    public static boolean isConnected() {
        return instance != null;
    }

    public static List<NotifItem> getRecent() {
        synchronized (RECENT) {
            return new ArrayList<>(RECENT);
        }
    }

    public static void clearRecent() {
        synchronized (RECENT) {
            RECENT.clear();
        }
    }

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        instance = this;
    }

    @Override
    public void onListenerDisconnected() {
        instance = null;
        super.onListenerDisconnected();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Exception ignored) {
            // Never crash the listener because of one odd notification.
        }
    }

    private void handle(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals(getPackageName())) return;

        Notification n = sbn.getNotification();
        if (n == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;

        Bundle extras = n.extras;
        if (extras == null) return;
        CharSequence titleCs = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence textCs = extras.getCharSequence(Notification.EXTRA_TEXT);
        String title = titleCs == null ? "" : titleCs.toString();
        String text = textCs == null ? "" : textCs.toString();
        if (title.isEmpty() && text.isEmpty()) return;

        NotifItem item = new NotifItem();
        item.pkg = pkg;
        item.title = title;
        item.text = text;
        item.time = System.currentTimeMillis();

        boolean replied = maybeAutoReply(pkg, n, extras, title, text);
        item.autoReplied = replied;

        synchronized (RECENT) {
            RECENT.add(item);
            while (RECENT.size() > MAX_RECENT) {
                RECENT.remove(0);
            }
        }

        ZuzuAutomationPlugin.emitNotification(item);
    }

    private boolean maybeAutoReply(String pkg, Notification n, Bundle extras, String title, String text) {
        SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(KEY_ENABLED, false)) return false;

        Set<String> allowed = new HashSet<>();
        for (String p : prefs.getString(KEY_APPS, DEFAULT_APPS).split(",")) {
            String t = p.trim();
            if (!t.isEmpty()) allowed.add(t);
        }
        if (!allowed.contains(pkg)) return false;

        // Never auto-reply inside group chats.
        if (extras.getBoolean("android.isGroupConversation", false)) return false;
        if (title.isEmpty()) return false;

        long cooldownMs = Math.max(1, prefs.getInt(KEY_COOLDOWN_MIN, 30)) * 60L * 1000L;
        String key = pkg + "|" + title;
        long now = System.currentTimeMillis();
        synchronized (LAST_REPLY_AT) {
            Long last = LAST_REPLY_AT.get(key);
            if (last != null && now - last < cooldownMs) return false;
        }

        if (n.actions == null) return false;
        String message = prefs.getString(KEY_MESSAGE, DEFAULT_MESSAGE);
        if (message == null || message.trim().isEmpty()) message = DEFAULT_MESSAGE;

        for (Notification.Action action : n.actions) {
            if (action == null || action.actionIntent == null) continue;
            RemoteInput[] inputs = action.getRemoteInputs();
            if (inputs == null || inputs.length == 0) continue;

            Intent fill = new Intent();
            Bundle results = new Bundle();
            for (RemoteInput ri : inputs) {
                results.putCharSequence(ri.getResultKey(), message);
            }
            RemoteInput.addResultsToIntent(inputs, fill, results);
            try {
                action.actionIntent.send(this, 0, fill);
                synchronized (LAST_REPLY_AT) {
                    LAST_REPLY_AT.put(key, now);
                }
                return true;
            } catch (PendingIntent.CanceledException ignored) {
                // try next action
            }
        }
        return false;
    }

    /** Helper for the plugin to turn an item into a JS object. */
    public static JSObject toJs(NotifItem item) {
        JSObject o = new JSObject();
        o.put("package", item.pkg);
        o.put("title", item.title);
        o.put("text", item.text);
        o.put("time", item.time);
        o.put("autoReplied", item.autoReplied);
        return o;
    }
}
