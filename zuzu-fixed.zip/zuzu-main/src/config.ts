// Zuzu AI backend URL (the server that runs server.ts).
// Example: "https://your-app-12345.us-west1.run.app"  (no slash at the end)
// Leave it empty ("") when running inside AI Studio / on the same website.
export const API_BASE_URL = "";
