import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import {API_BASE_URL} from './config.ts';

// In the Android APK there is no local server, so send /api/... calls to the real backend.
if (API_BASE_URL) {
  const originalFetch = window.fetch.bind(window);
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
    if (typeof input === 'string' && input.startsWith('/api/')) {
      return originalFetch(API_BASE_URL + input, init);
    }
    return originalFetch(input, init);
  };
}

createRoot(document.getElementById('root')!).render(<App />);
